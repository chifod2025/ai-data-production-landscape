import GitHubLanding from "@/components/GitHubLanding";

const Index = () => {
  return <GitHubLanding />;
};

export default Index;
