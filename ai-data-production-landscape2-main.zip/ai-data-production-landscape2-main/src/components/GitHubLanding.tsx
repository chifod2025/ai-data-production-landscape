import { Github, Star, GitFork, ExternalLink } from "lucide-react";
import { HeroButton } from "./ui/hero-button";

const GitHubLanding = () => {
  return (
    <div className="min-h-screen bg-hero-gradient">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-hero-overlay"></div>
        
        <div className="relative z-10 text-center max-w-4xl mx-auto">
          <div className="animate-fade-in">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Beautiful
              <span className="block bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent">
                Open Source
              </span>
            </h1>
            
            <p className="text-xl sm:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
              Discover something amazing. Built with passion, designed for simplicity, 
              crafted for developers who care about beautiful code.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in">
            <HeroButton
              variant="hero"
              size="xl"
              className="group"
              onClick={() => window.open('https://github.com', '_blank')}
            >
              <Github className="mr-2 h-5 w-5 group-hover:rotate-12 transition-transform" />
              View on GitHub
            </HeroButton>
            
            <HeroButton
              variant="outline"
              size="xl"
              className="group"
              onClick={() => window.open('https://github.com', '_blank')}
            >
              <ExternalLink className="mr-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              Live Demo
            </HeroButton>
          </div>
          
          <div className="flex items-center justify-center gap-6 mt-8 text-white/80 animate-fade-in">
            <div className="flex items-center gap-2">
              <Star className="h-5 w-5" />
              <span className="text-sm">Star on GitHub</span>
            </div>
            <div className="flex items-center gap-2">
              <GitFork className="h-5 w-5" />
              <span className="text-sm">Fork & Contribute</span>
            </div>
          </div>
        </div>
        
        {/* Floating elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-white/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse"></div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/5 to-transparent"></div>
        
        <div className="relative z-10 max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
              Why Choose This Project?
            </h2>
            <p className="text-lg text-white/80 max-w-2xl mx-auto">
              Built with modern technologies and best practices in mind.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Modern Stack",
                description: "Built with the latest technologies and frameworks for optimal performance.",
                icon: "⚡"
              },
              {
                title: "Clean Code",
                description: "Well-documented, maintainable code that follows industry best practices.",
                icon: "✨"
              },
              {
                title: "Open Source",
                description: "Free to use, modify, and contribute. Join our growing community.",
                icon: "🔓"
              }
            ].map((feature, index) => (
              <div 
                key={index}
                className="text-center p-8 rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 transition-all duration-300 hover:scale-105"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-white mb-4">{feature.title}</h3>
                <p className="text-white/80 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-lg text-white/80 mb-8 max-w-2xl mx-auto">
            Join thousands of developers who have already discovered the power of this project.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <HeroButton
              variant="hero"
              size="xl"
              onClick={() => window.open('https://github.com', '_blank')}
            >
              <Github className="mr-2 h-5 w-5" />
              Get Started Now
            </HeroButton>
            
            <HeroButton
              variant="outline"
              size="xl"
              onClick={() => window.open('https://github.com', '_blank')}
            >
              Read Documentation
            </HeroButton>
          </div>
        </div>
      </section>
    </div>
  );
};

export default GitHubLanding;